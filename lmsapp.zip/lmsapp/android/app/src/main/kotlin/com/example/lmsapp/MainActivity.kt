package com.example.lmsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
