import 'package:flutter/material.dart';

class AppColors {
  static const MaterialColor primaryColor = Colors.amber; // Your primary color
  static const Color secondaryColor = Colors.deepPurple;
  static const Color backgroundColor = Colors.white;
  static const Color textColor = Colors.black;
  static const Color errorColor = Colors.red;
}
