import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import 'package:lmsapp/features/courses/view/course_list_page.dart';
import 'package:lmsapp/features/profile/view/profile_page.dart';

class BaseScreen extends StatefulWidget {
  final String email;

  const BaseScreen({Key? key, required this.email}) : super(key: key);

  @override
  _BaseScreenState createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: _selectedIndex == 0
          ? CourseListPage()
          : ProfilePage(email: widget.email), // Pass the email to ProfilePage
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Iconsax.book),
            label: 'Courses',
          ),
          BottomNavigationBarItem(
            icon: Icon(Iconsax.people),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
