import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

//Model
class Course {
  final String id;
  final String name;
  final String description;
  final String courseImageUrl;
  final String courseStartDate;
  final String courseEndDate;

  Course({
    required this.id,
    required this.name,
    required this.description,
    required this.courseImageUrl,
    required this.courseStartDate,
    required this.courseEndDate,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    final media = json['media'] ?? {};
    final courseImageUri = media['course_image']?['uri'] ?? '';
    final baseImageUrl = 'https://courses.edx.org';

    return Course(
      id: json['course_id'] ?? '',
      name: json['name'] ?? 'No name available',
      description: json['org'] ?? 'No description available',
      courseImageUrl: baseImageUrl + courseImageUri,
      courseStartDate: json['start'] != null
          ? DateFormat('dd MMM yyyy').format(DateTime.parse(json['start']))
          : 'No start date available',
      courseEndDate: json['end'] != null
          ? DateFormat('dd MMM yyyy').format(DateTime.parse(json['end']))
          : 'No end date available',
    );
  }
}

//State
class CourseState {
  final List<Course> courses;
  final bool isLoading;
  final String errorMessage;

  CourseState({
    required this.courses,
    required this.isLoading,
    required this.errorMessage,
  });

  factory CourseState.initial() {
    return CourseState(
      courses: [],
      isLoading: true,
      errorMessage: '',
    );
  }

  CourseState copyWith({
    List<Course>? courses,
    bool? isLoading,
    String? errorMessage,
  }) {
    return CourseState(
      courses: courses ?? this.courses,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}

//Cubit
class CourseCubit extends Cubit<CourseState> {
  CourseCubit() : super(CourseState.initial());

  Future<void> fetchCourses() async {
    try {
      final response = await http.get(Uri.parse('https://courses.edx.org/api/courses/v1/courses'));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final List<dynamic> courseData = data['results'];

        emit(state.copyWith(
          courses: courseData.map((course) => Course.fromJson(course)).toList(),
          isLoading: false,
        ));
      } else {
        emit(state.copyWith(
          errorMessage: 'Failed to load courses. Status code: ${response.statusCode}',
          isLoading: false,
        ));
      }
    } catch (e) {
      emit(state.copyWith(
        errorMessage: 'An error occurred: $e',
        isLoading: false,
      ));
    }
  }
}

//View
class CourseListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center, 
          children: [
            Image.asset(
              'assets/icon.png', 
              height: 30, 
            ),
            const SizedBox(width: 8),
            Text(
              'Courses',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false, 
      ),
      body: BlocProvider(
        create: (_) => CourseCubit()..fetchCourses(),
        child: BlocBuilder<CourseCubit, CourseState>(
          builder: (context, state) {
            if (state.isLoading) {
              return Center(child: CircularProgressIndicator());
            }

            if (state.errorMessage.isNotEmpty) {
              return Center(child: Text(state.errorMessage));
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Showing ${state.courses.length} Courses',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[700],
                    ),
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: state.courses.length,
                    itemBuilder: (context, index) {
                      final Course course = state.courses[index];
                      return Container(
                        margin: EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 8,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        child: InkWell(
                          onTap: () {},
                          borderRadius: BorderRadius.circular(12),
                          child: Padding(
                            padding: EdgeInsets.all(12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    course.courseImageUrl,
                                    width: 80,
                                    height: 80,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) =>
                                        Container(
                                      width: 80,
                                      height: 80,
                                      color: Colors.grey[200],
                                      child: Icon(Icons.image,
                                          color: Colors.grey[400]),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        course.name,
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        course.description,
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey[600],
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        'Starts: ${course.courseStartDate}',
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey[600],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
