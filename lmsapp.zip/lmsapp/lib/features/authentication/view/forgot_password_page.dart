import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ForgotPasswordPage extends StatefulWidget {
  @override
  _ForgotPasswordPageState createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _emailController = TextEditingController();
  bool _isLoading = false;
  bool _isSuccess = false;
  String _message = '';


  Future<void> _sendResetLink(String email) async {
    final url = 'https://taskserver-squadra.onrender.com/graphql';

    setState(() {
      _isLoading = true;
      _isSuccess = false;
    });

    final response = await http.post(
      Uri.parse(url),
      headers: {
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'query': '''
          mutation ForgotPassword(\$email: String!) {
            forgotPassword(email: \$email)
          }
        ''',
        'variables': {
          'email': email,
        },
      }),
    );

    if (response.statusCode == 200) {
      final responseBody = json.decode(response.body);
      final message = responseBody['data']['forgotPassword'];

      setState(() {
        _isLoading = false;
        _isSuccess = true;
        _message = message ?? 'Password reset link sent successfully!';
      });

      Future.delayed(const Duration(seconds: 3), () {
        Navigator.pop(context); 
      });
    } else {
      setState(() {
        _isLoading = false;
        _message = 'Failed to reset password. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              Container(
                alignment: Alignment.center,
                child: Icon(
                  Icons.lock_reset_outlined,
                  size: 80,
                  color: Colors.blue[300],
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Forgot Password',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                'Please enter your email address. You will receive a link to create a new password via email.',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email_outlined),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[100],
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () {
                  String email = _emailController.text.trim();
                  if (email.isNotEmpty) {
                    _sendResetLink(email); 
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[400],
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Send Reset Link',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white
                  ),
                ),
              ),
              const SizedBox(height: 24),
              _isLoading
                  ? Center(child: CircularProgressIndicator())
                  : Column(
                      children: [
                        if (_isSuccess)
                          Icon(
                            Icons.check_circle,
                            size: 100,
                            color: Colors.green,
                          ),
                        const SizedBox(height: 20),
                        Text(
                          _message,
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _isSuccess ? Colors.green : Colors.red),
                          textAlign: TextAlign.center,
                        ),
                        if (!_isSuccess)
                          const SizedBox(height: 40),
                        if (!_isSuccess)
                          ElevatedButton(
                            onPressed: () {
                              String email = _emailController.text.trim();
                              if (email.isNotEmpty) {
                                _sendResetLink(email); 
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[100],
                              
                              padding: const EdgeInsets.symmetric(vertical: 0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: const Text(
                              'Retry',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
                            ),
                          ),
                      ],
                    ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }
}
